# Programador:

# Importar las librerías necesarias
import sqlite3 #pip install sqlite3
import tkinter as tk
from tkinter import Tk, Label, Entry, Button, Menu, messagebox, ttk
import os
from PIL import Image, ImageTk # pip install Pillow

base_de_datos="biblioteca.db"

# Función para obtener todos los libros de la base de datos
def consultar(con):
    conexion = sqlite3.connect(base_de_datos)
    cursor = conexion.cursor()
    cursor.execute(con) 
    datos = cursor.fetchall() # Guardamos los resultados en una variable
    conexion.close() # Cerramos la conexión
    return datos # Devolvemos los datos obtenidos

# Función para crear una base de datos
def crear_bd():
    try:
        # Crear (o conectar si ya existe) la base de datos llamada 'borrador.db'
        conexion2 = sqlite3.connect(bd_borrador)

        # Si llegamos aquí, la base de datos fue creada o conectada correctamente
        messagebox.showinfo("Mensaje", f"Base de datos '{bd_borrador}' creada con éxito.")
        
    except sqlite3.Error as error:
        # En caso de que ocurra un error al intentar crear o conectar a la base de datos
        messagebox.showinfo("Mensaje", f"Error al crear o conectar a la base de datos: {error}")
        

    finally:
        # Cerrar la conexión si está abierta
        if 'conexion' in locals():
            conexion2.close()
            messagebox.showinfo("Mensaje", "Conexión cerrada")

def renombrar_bd():
    messagebox.showinfo("Mensaje", "en SQL no se puede renombrar una BD directamente")

def borrar_bd():
    try:
        if os.path.exists(bd_borrador): # Verificar si el archivo de la base de datos existe
            os.remove(bd_borrador) # Eliminar el archivo de la base de datos
            messagebox.showinfo("Mensaje", f"La base de datos '{bd_borrador}' fue eliminada con éxito.")
            print()
        else:
            messagebox.showinfo("Mensaje", f"La base de datos '{nombre_bd}' no existe.")

    except Exception as error:
        messagebox.showinfo("Mensaje", f"Error al eliminar la base de datos: {error}")

def crear_tabla():
    # Crear (o conectar si ya existe) la base de datos llamada 'borrador.db'
    conexion2 = sqlite3.connect(bd_borrador)
    cursor = conexion2.cursor() # Crear un cursor para interactuar con la base de datos

    # Crear la tabla 'ejemplo' en la base de datos
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS ejemplo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        edad INTEGER
    )
    ''')

    conexion2.commit() # Guardar los cambios
    conexion2.close() # Cerrar la conexión
    messagebox.showinfo("Mensaje", "Conexión cerrada")

def cambiar_nombre_tabla():
    try:
        conexion2 = sqlite3.connect(bd_borrador) # Conectar a la base de datos
        cursor=conexion2.cursor() # Crear un cursor para ejecutar comandos SQL
        cursor.execute('ALTER TABLE ejemplo RENAME TO nuevo_nombre') # Renombrar la tabla 'ejemplo' a 'nuevo_nombre'
        conexion2.commit() # Guardar los cambios
        messagebox.showinfo("Mensaje","Tabla renombrada con éxito.")

    except sqlite3.Error as error:
        # Si ocurre un error, lo capturamos y mostramos el mensaje
        messagebox.showinfo("Mensaje",f"Error al renombrar la tabla: {error}")

    finally:
        # Cerrar la conexión
        if 'conexion' in locals():
            conexion.close()
            messagebox.showinfo("Mensaje", "Conexión cerrada")

def borrar_tabla():
    try:
        conexion2 = sqlite3.connect(bd_borrador) # Conectar a la base de datos
        cursor=conexion2.cursor() # Crear un cursor para ejecutar comandos SQL
        cursor.execute('DROP TABLE IF EXISTS ejemplo') # Borrar la tabla si existe
        conexion2.commit() # Guardar los cambios
        messagebox.showinfo("Mensaje","Tabla borrada con éxito.")

    except sqlite3.Error as error:
        # Si ocurre un error, lo capturamos y mostramos el mensaje
        messagebox.showinfo("Mensaje",f"Error al borrar la tabla: {error}")

    finally:
        # Cerrar la conexión
        if 'conexion' in locals():
            conexion.close()
            messagebox.showinfo("Mensaje", "Conexión cerrada")

# Configuración de la interfaz gráfica (Tkinter)
def interfaz():
    # Función cargar gif
    def cargar_gif():
        gif = Image.open("lector.gif") # Abrir el archivo GIF con Pillow
        frames = [] # Obtener los frames del GIF
        try:
            while True:
                frame = ImageTk.PhotoImage(gif.copy())
                frames.append(frame)
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass  # Fin de los frames

        # Crear un Label para mostrar el GIF
        etiqueta = tk.Label(ventana)
        etiqueta.place(x=2,y=350)
        # Función para actualizar el GIF (para animación)
        def actualizar_frame(frame_idx):
            etiqueta.config(image=frames[frame_idx])
            etiqueta.image = frames[frame_idx]
            ventana.after(400, actualizar_frame, (frame_idx + 1) % len(frames))
        # Iniciar la animación con el primer frame
        actualizar_frame(0)
        
    # Función para cargar los libros en la tabla
    def cargar_libros(consulta):
        for fila in tabla.get_children(): # Obtiene los elementos que están dentro de Treeview
            tabla.delete(fila) # Elimina una fila de Treeview
                        
        for libro in consultar(consulta):
            tabla.insert("", "end", values=libro) #inserta una fila            
        
        eti_num_registros.config(text=f"Número de Registros= {len(tabla.get_children())}")
    
    def contar_libros(consulta):
        num_libros=consultar(consulta)[0][0]
        messagebox.showinfo("Num. libros", f"{num_libros} libros")
        
    def limpiar_tabla():
        for fila in tabla.get_children(): # Obtiene los elementos que están dentro de Treeview
            tabla.delete(fila) # Elimina una fila de Treeview
        eti_num_registros.config(text="")  
    # Función para cerrar la ventana
    def cerrar_ventana():
        ventana.destroy()
    
    
    # Ventana principal
    ventana = Tk()
    ancho,alto=1200,700 # Tamaño de la ventana
    colorFondo="#F5F1A6" # Color de fondo de la ventana
    obraVentana="Control de libros"
    ancho_pantalla = ventana.winfo_screenwidth()
    alto_pantalla = ventana.winfo_screenheight()
    ventana.title(obraVentana) # Título de la ventana
    if(ancho==0 or alto==0):
        ventana.state('zoomed') # la ventana ocupa toda la pantalla
    else:
        ventana.geometry(str(ancho)+"x"+str(alto)) # establece tamaño de la ventana
        # Calcula la posición de la ventana en el centro de la pantalla
        x = (ancho_pantalla // 2) - (ancho // 2)
        y = (alto_pantalla // 2) - (alto // 2)
        ventana.resizable(width=False,height=False) # No permite redimensionar la ventana
        ventana.config(bg=colorFondo) # Color de fondo-Background
        ventana.geometry(f"+{x}+{y}")     # Mostrar la ventana en el centro de la pantalla
    
    cargar_gif()
    
    # Crear el Menú de la aplicación
    barra_menu = tk.Menu(ventana)
    ventana.config(menu=barra_menu)
    barra_menu.config(bg="red", fg="white") # Cambiar el color de fondo y el texto de la barra de menús
   
    # Menú de la Opción Archivo
    menu_archivo = Menu(barra_menu, tearoff=0) #creando un menú en una ventana principal (barra_menu) y lo guarda en la variable menu_archivo.
                            #Además, se establece que el menú no tendrá la funcionalidad de desprenderse (con tearoff=0).
    menu_archivo.add_command(label="Salir", command=cerrar_ventana)
    menu_archivo.config(bg="black", fg="red") # Cambiar el color del texto y el fondo del menú
    
    # Menú de la Opción bases de datos
    bases_de_datos = Menu(barra_menu, tearoff=0)
    bases_de_datos.add_command(label="Crear bd", command=crear_bd)
    bases_de_datos.add_command(label="Renombrar BD", command=renombrar_bd)
    bases_de_datos.add_separator()
    bases_de_datos.add_command(label="Borrar BD", command=borrar_bd)
    bases_de_datos.config(bg="lightblue", fg="darkred") # Cambiar el color del texto y el fondo del menú

# Menú de la Opción tablas
    tablas = Menu(barra_menu, tearoff=0)
    tablas.add_command(label="Crear tabla", command=crear_tabla)
    tablas.add_command(label="Renombrar tabla", command=cambiar_nombre_tabla)
    tablas.add_command(label="Borrar tabla", command=borrar_tabla)
    tablas.config(bg="lightyellow", fg="darkred") # Cambiar el color del texto y el fondo del menú

    # Agregar los menús al menú principal
    barra_menu.add_cascade(label="Archivo", menu=menu_archivo)
    barra_menu.add_cascade(label="BD ejemplos", menu=bases_de_datos)
    barra_menu.add_cascade(label="Tablas ejemplos", menu=tablas)
    
    #agregar otra opción almenú
    barra_menu.add_command(label="Acerca de", command=lambda: messagebox.showinfo("Acerca de", "Control de LIBROS v1.0"))
    
    
    # Etiquetas y entradas para los datos del libro
    eti_titulo=Label(ventana, text="CONSULTAS:",font=("arial black",18),bg=colorFondo)
    eti_titulo.place(relx=0.5, y=20, anchor="center")  # Centra el label en la ventana
    
    eti_num_registros=Label(ventana, text="",font=("arial",10),bg=colorFondo)
    eti_num_registros.place(x=300,y=670)

    la_consulta=[]
    # Botón consulta 
    la_consulta.append("SELECT * FROM los_libros;")
    btn_consulta1 = Button(text="Listar todos los libros",cursor="hand2",command=lambda:cargar_libros(la_consulta[0]))
    btn_consulta1.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta1.bind("<Enter>", func=lambda e: btn_consulta1.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta1.bind("<Leave>", func=lambda e: btn_consulta1.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta1.place(x=50,y=50)
    
    # Botón consulta
    la_consulta.append("SELECT * FROM los_libros WHERE anio<1900 ORDER BY anio;")
    btn_consulta2 = Button(text="Listar todos los libros escritos antes de 1900",cursor="hand2",command=lambda:cargar_libros(la_consulta[1]))
    btn_consulta2.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta2.bind("<Enter>", func=lambda e: btn_consulta2.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta2.bind("<Leave>", func=lambda e: btn_consulta2.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta2.place(x=50,y=80)
    
    # Botón consulta
    la_consulta.append("SELECT * FROM los_libros WHERE obra LIKE 'L%';")
    btn_consulta3 = Button(text="Listar todos los libros cuyo título empieza por la letra L",cursor="hand2",command=lambda:cargar_libros(la_consulta[2]))
    btn_consulta3.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta3.bind("<Enter>", func=lambda e: btn_consulta3.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta3.bind("<Leave>", func=lambda e: btn_consulta3.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta3.place(x=50,y=110)
    
    # Botón consulta
    la_consulta.append("SELECT * FROM los_libros ORDER BY obra ;")
    btn_consulta4 = Button(text="Listar alfabéticamente todos los libros ordenados por título",cursor="hand2",command=lambda:cargar_libros(la_consulta[3]))
    btn_consulta4.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta4.bind("<Enter>", func=lambda e: btn_consulta4.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta4.bind("<Leave>", func=lambda e: btn_consulta4.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta4.place(x=50,y=140)
    
    # Botón consulta
    la_consulta.append("SELECT * FROM los_libros ORDER BY anio ASC LIMIT 6 ;")
    btn_consulta5 = Button(text="Listar los 6 libros más antiguos",cursor="hand2",command=lambda:cargar_libros(la_consulta[4]))
    btn_consulta5.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta5.bind("<Enter>", func=lambda e: btn_consulta5.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta5.bind("<Leave>", func=lambda e: btn_consulta5.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta5.place(x=50,y=170)
    
    # Botón consulta
    la_consulta.append("SELECT * FROM los_libros WHERE autor LIKE '%luis%' ORDER BY AUTOR ASC;")
    btn_consulta6 = Button(text="Listar todos los libros escritos por Luis",cursor="hand2",command=lambda:cargar_libros(la_consulta[5]))
    btn_consulta6.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta6.bind("<Enter>", func=lambda e: btn_consulta6.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta6.bind("<Leave>", func=lambda e: btn_consulta6.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta6.place(x=50,y=200)
        
    # Botón consulta
    la_consulta.append("SELECT COUNT(anio) FROM los_libros WHERE anio BETWEEN '1990' AND '1995';")
    btn_consulta7 = Button(text="Número de libros que fueron escritos entre 1990 y 1995, ambos inclusive",cursor="hand2",
                           command=lambda:contar_libros(la_consulta[6]))
    btn_consulta7.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta7.bind("<Enter>", func=lambda e: btn_consulta7.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta7.bind("<Leave>", func=lambda e: btn_consulta7.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta7.place(x=50,y=230)
    
    # Botón consulta
    la_consulta.append("SELECT COUNT(*) FROM los_libros WHERE obra LIKE 'c%' ;")
    btn_consulta8 = Button(text="Número de libros cuyo título empieza por la letra c",cursor="hand2",
                           command=lambda:contar_libros(la_consulta[7]))
    btn_consulta8.config(font=("Arial Bold",10),fg="#1E9EB8",bg="#E7ECED",width=60)
    btn_consulta8.bind("<Enter>", func=lambda e: btn_consulta8.config(bg="#1E9EB8",fg="#E7ECED")) # Al presionar enter
    btn_consulta8.bind("<Leave>", func=lambda e: btn_consulta8.config(fg="#1E9EB8",bg="#E7ECED")) # mouse sale del área del widget
    btn_consulta8.place(x=50,y=260)
    
    # Botón para limpiar la tabla
    btnLimpiar = Button(text="LIMPIAR TABLA",cursor="hand2",command=limpiar_tabla)
    btnLimpiar.config(font=("Arial Bold",8),fg="#1E9EB8",bg="#E7ECED",width=15)
    btnLimpiar.bind("<Enter>", func=lambda e: btnLimpiar.config(bg="#1E9EB8",fg="#E7ECED"))
    btnLimpiar.bind("<Leave>", func=lambda e: btnLimpiar.config(fg="#1E9EB8",bg="#E7ECED"))
    btnLimpiar.place(x=850,y=670)

    # Tabla para mostrar los libros
    columnas = ("Cod", "Título", "Autor", "País", "Año")
    tabla = ttk.Treeview(ventana, columns=columnas, show="headings", height=15)
    # Ajustamos el ancho de las columnas
    tabla.column(0, minwidth=0, width=30)
    tabla.column(1, minwidth=0, width=250)
    tabla.column(2, minwidth=0, width=250)
    tabla.column(3, minwidth=0, width=200)
    tabla.column(4, minwidth=0, width=50)
    tabla.place(relx=0.5, y=500, anchor="center")  # Centra el label en la ventana
    
    for col in columnas:
        tabla.heading(col, text=col) # Títulos de las columnas

    # Agrega una barra de desplazamiento
    scrollbar = ttk.Scrollbar(ventana, orient=tk.VERTICAL, command=tabla.yview) # Crea una barra de desplazamiento (scrollbar) vertical
    scrollbar.place(x=1000,y=340,height=320) # Ubica la barra de desplazamiento en la ventana y ajusta su tamaño
    tabla.config(yscroll=scrollbar.set) # Configura a tabla para que utilice la barra de desplazamiento creada
    
    ventana.mainloop() # Ejecutamos el bucle principal de la interfaz gráfica


if __name__ == "__main__":
    interfaz()
